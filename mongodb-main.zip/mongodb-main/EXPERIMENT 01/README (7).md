# mongodb_1
<img width="1536" height="281" alt="Screenshot 2025-10-12 at 12 03 51 am" src="https://github.com/user-attachments/assets/8394a03e-3a66-4455-bab1-b8e3f76e915a" />
