# mongodb_3
<img width="1536" height="551" alt="Screenshot 2025-10-12 at 1 06 07 am" src="https://github.com/user-attachments/assets/dedffa2c-3098-4161-a486-00055d9ab2b9" />
