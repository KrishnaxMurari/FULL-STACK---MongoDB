<img width="1536" height="484" alt="Screenshot 2025-10-12 at 12 52 40 am" src="https://github.com/user-attachments/assets/adb0ff83-f185-4fd0-a3a8-c0df797fee89" />
